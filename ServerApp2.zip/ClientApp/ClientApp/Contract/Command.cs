﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServerApp2.Contract
{
    public class Command
    {
        public string Message { get; set; }
        public CommandType Type { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public List<byte> File { get; set; }

        public enum CommandType
        {
            File,
            Message,
            PublicMessage,
            PrivateMessage,
            Authorization,
            PrivateFile
        }
    }
}