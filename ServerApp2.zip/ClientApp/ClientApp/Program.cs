﻿using System;
using ClientApp;
using ServerApp2.Contract;
using static ServerApp2.Contract.Command;

var client = new NetClient();
client.Connect("10.10.21.41", 2324);
Task.Run(() => client.StartReceiving());

while (true)
{
    if (client.IsAuthorize)
    {
        Console.WriteLine("Enter 1 to send Private, 2 to send Public:,3 Send file");
        var choice = Console.ReadLine();
        if (choice == "1")
        {
            Console.WriteLine("Enter recipient name:");
            var toName = Console.ReadLine();
            Console.WriteLine("Enter message:");
            var message = Console.ReadLine();
            client.SendCommand(new Command
            {
                From = client.UserName,
                To = toName,
                Message = message,
                Type = CommandType.PrivateMessage
            });
        }
        else if (choice == "2")
        {
            Console.WriteLine("Enter message:");
            var message = Console.ReadLine();
            client.SendCommand(new Command
            {
                From = client.UserName,
                Message = message,
                Type = CommandType.PublicMessage
            });
        }
        else if (choice == "3")
        {
            Console.WriteLine("Enter name:");
            var toName = Console.ReadLine();
            Console.WriteLine("file path:");
            var filePath = Console.ReadLine();

            if (File.Exists(filePath))
            {
                var fileName = Path.GetFileName(filePath);
                var fileBytes = File.ReadAllBytes(filePath);

                client.SendCommand(new Command
                {
                    From = client.UserName,
                    To = toName,
                    Message = fileName,
                    File = fileBytes.ToList(),
                    Type = CommandType.PrivateFile
                });

                Console.WriteLine($"File '{fileName}' sent to {toName}");
            }
            else
            {
                Console.WriteLine("File not found!");
            }
        }
     
    }
  
    
    else
    {
        Console.WriteLine("authorize:");
        var name = Console.ReadLine();
        client.SendCommand(new Command
        {
            Message = name,
            Type = CommandType.Authorization
        });
        Thread.Sleep(1000);
    }
}
