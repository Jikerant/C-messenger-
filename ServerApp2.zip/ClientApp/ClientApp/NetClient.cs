﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ServerApp2.Contract;

namespace ClientApp
{
    public class NetClient
    {
        public TcpClient _clientSocket { get; set; }
        public bool IsAuthorize { get; set; } = false;
        public string UserName { get; set; }

        public NetClient()
        {
            _clientSocket = new TcpClient();
        }

        public void Connect(string ipAddress, int port)
        {
            _clientSocket.Connect(ipAddress, port);
        }

        public void SendCommand(Command command)
        {
            var jsonCommand = JsonConvert.SerializeObject(command);
            var commandBytes = Encoding.UTF8.GetBytes(jsonCommand);
            var stream = _clientSocket.GetStream();
            var writer = new BinaryWriter(stream, Encoding.UTF8);
            writer.Write(commandBytes.Length);
            writer.Write(commandBytes);
            writer.Flush();
        }

        public void StartReceiving()
        {
            var stream = _clientSocket.GetStream();
            var reader = new BinaryReader(stream, Encoding.UTF8);

            while (true)
            {
                try
                {
                    int size = reader.ReadInt32();
                    byte[] buffer = reader.ReadBytes(size);
                    var jsonCommand = Encoding.UTF8.GetString(buffer);
                    var command = JsonConvert.DeserializeObject<Command>(jsonCommand);
                    CommandExecuted(command);
                }
                catch (IOException ex)
                {
                    Console.WriteLine($"Connection closed: {ex.Message}");
                    break;
                }
            }
        }

        public void CommandExecuted(Command command)
        {
            switch (command.Type)
            {
                case Command.CommandType.Authorization:
                    IsAuthorize = true;
                    UserName = command.Message;
                    Console.WriteLine($"Authorized as {UserName}");
                    break;

                case Command.CommandType.PublicMessage:
                    Console.WriteLine($"[Public] {command.From}: {command.Message}");
                    break;

                case Command.CommandType.PrivateMessage:
                    Console.WriteLine($"[Private] {command.From} -> you: {command.Message}");
                    break;

                case Command.CommandType.Message:
                    Console.WriteLine($"[Message] {command.Message}");
                    break;

                case Command.CommandType.PrivateFile:
                    Console.WriteLine($"[File] {command.From} sent you a file: {command.Message}");
                    File.WriteAllBytes(Path.Combine(Directory.GetCurrentDirectory(), command.Message), command.File.ToArray());
                    break;
            }
        }
    }
}
