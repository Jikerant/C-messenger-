﻿
using ServerApp2;
var serverService = new ServerService();
serverService.StartServer(2324);
