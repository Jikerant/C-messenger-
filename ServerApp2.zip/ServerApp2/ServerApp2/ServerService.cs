﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ServerApp2.Contract;
using static ServerApp2.Contract.Command;

namespace ServerApp2
{
    public class ServerService
    {
        private TcpListener _listener;
        private Dictionary<string, TcpClient> _userSockets = new();

        public void StartServer(int port)
        {
            _listener = new TcpListener(IPAddress.Parse("10.10.21.41"), port);
            _listener.Start();
            Console.WriteLine("Server started");

            while (true)
            {
                var client = _listener.AcceptTcpClient();
                Task.Run(() => ClientConnected(client));
            }
        }

        private void ClientConnected(TcpClient tcpClient)
        {
            var stream = tcpClient.GetStream();
            var reader = new BinaryReader(stream, Encoding.UTF8);
            var writer = new BinaryWriter(stream, Encoding.UTF8);

            try
            {
                while (true)
                {
                    int size = reader.ReadInt32();
                    byte[] buffer = reader.ReadBytes(size);
                    var json = Encoding.UTF8.GetString(buffer);
                    var command = JsonConvert.DeserializeObject<Command>(json);
                    if (command != null)
                    {
                        CommandExecuted(command, tcpClient);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Client error: {ex.Message}");
                foreach (var user in _userSockets)
                {
                    if (user.Value == tcpClient)
                    {
                        _userSockets.Remove(user.Key);
                        break;
                    }
                }
            }
        }

        public void CommandExecuted(Command command, TcpClient client)
        {
            switch (command.Type)
            {
                case CommandType.Authorization:
                    _userSockets[command.Message] = client;
                    Broadcast(new Command
                    {
                        Type = CommandType.Authorization,
                        Message = command.Message
                    });
                    break;

                case CommandType.PublicMessage:
                    Console.WriteLine($"[Public] {command.From}: {command.Message}");
                    Broadcast(command);
                    break;

                case CommandType.PrivateMessage:
                    if (_userSockets.TryGetValue(command.To, out var receiver))
                        SendToClient(receiver, command);
                    break;

                case CommandType.PrivateFile:
                    if (_userSockets.TryGetValue(command.To, out var receiverF))
                    {
                        SendToClient(receiverF, command);
                        File.WriteAllBytes(command.Message, command.File.ToArray());
                    }
                    break;

                case CommandType.File:
                    File.WriteAllBytes(command.Message, command.File.ToArray());
                    break;

                case CommandType.Message:
                    Console.WriteLine($"[Message] {command.Message}");
                    break;
            }
        }

        private void Broadcast(Command command)
        {
            foreach (var client in _userSockets.Values)
            {
                SendToClient(client, command);
            }
        }

        private void SendToClient(TcpClient client, Command command)
        {
            try
            {
                var json = JsonConvert.SerializeObject(command);
                var bytes = Encoding.UTF8.GetBytes(json);
                var stream = client.GetStream();
                var writer = new BinaryWriter(stream, Encoding.UTF8);
                writer.Write(bytes.Length);
                writer.Write(bytes);
                writer.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Send error: {ex.Message}");
            }
        }
    }
}
